import $ from "jquery";
import slick from "slick-carousel";
import "./css/index.css";
import "./scss/index.scss";

$(".my-carousel").slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 1,

  nextArrow: '<div class="slider__next"></div>',
  prevArrow: '<div class="slider__prev"></div>',

  responsive: [
    {
      breakpoint: 900,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
